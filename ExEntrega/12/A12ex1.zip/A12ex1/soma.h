#ifndef SOMA_H
#define SOMA_H


int soma_entre_numeros(int n1, int n2);

#endif