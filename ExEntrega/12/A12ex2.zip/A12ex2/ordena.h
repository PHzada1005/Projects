#ifndef ORDENA_H
#define ORDENA_H

#define TAM 10

void ordena_vetor(int vetor[TAM]);



#endif