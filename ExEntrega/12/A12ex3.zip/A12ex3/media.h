#ifndef MEDIA_H
#define MEDIA_H

#define TAM 12

int media_ari(int matriz[TAM][TAM]);



#endif